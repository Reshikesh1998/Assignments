package com.thinkitive.SpringEmployeAssignment.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.thinkitive.Employee.Employee;
import com.thinkitive.Employee.Employeeoperations;

@Controller
public class HomeController {

Employeeoperations o = new Employeeoperations() ;
	@RequestMapping(value="/")
	public ModelAndView test(HttpServletResponse response) throws IOException{
		return new ModelAndView("home");
	}
	
	@RequestMapping(value = "/new")
	public ModelAndView addemploye(String ename, Integer empid, Integer Salary , String operation)
	
	{
	
		ModelAndView model = new ModelAndView();
		System.out.println(operation);
		if(operation.equals("1")) 
		{
			//add
			Employee e = new Employee(empid, ename, Salary);
			o.addEmployee(e);
		}
		if(operation.equals("2"))
		{
			//delete
			
			o.deleteEmployee(empid);
		}
		if(operation.equals("3")) 
		{
			//update
			Employee e = new Employee(empid, ename, Salary);
			o.updateEmployee(e);
			
		}
		if(operation.equals("4"))
		{
			//get
			Employee e = o.getEmployee(empid);
			model.addObject("elist", e.toString());
		}
		if(operation.equals("5"))
		{
			//all
			List< Employee> l = o.getallEmployee();
			model.addObject("elist", l.toString());
		}
		
		
		model.setViewName("index.jsp");
		return model;
		
	}
}
