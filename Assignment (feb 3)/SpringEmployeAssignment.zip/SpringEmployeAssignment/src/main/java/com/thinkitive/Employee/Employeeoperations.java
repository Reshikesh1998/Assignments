package com.thinkitive.Employee;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
@Component
public class Employeeoperations implements EmplyeeMethods{
List<Employee> elist = new ArrayList<Employee>();

Configuration cfg ;
SessionFactory factory;
Session session;
Transaction tx;
public Employeeoperations() {
	cfg=  new Configuration();
	factory = cfg.configure().buildSessionFactory();
}

	@Override
	public void addEmployee(Employee e) {
		
	//	session = factory.openSession();
		//tx = session.beginTransaction();
		
		//session.save(e);
		
	elist.add(e);
		
	}

	@Override
	public void deleteEmployee(int empid) {
		
		for(Employee x : elist) 
		{
			if(empid == x.getEmpid()) 
			{
				elist.remove(x);
			}
		}
		
	}

	@Override
	public void updateEmployee(Employee e) {
		
		for(Employee x : elist) 
		{
			if(e.getEmpid() == x.getEmpid()) 
			{
				x.setEname(e.getEname());
				x.setSalary(e.getEmpid());
			}
		}
	}

	@Override
	public Employee getEmployee(int empid) {
		
		for(Employee x : elist) 
		{
			if(empid== x.getEmpid()) 
			{
				return x;
			}
		}
		return null;
	}

	@Override
	public List<Employee> getallEmployee() {
	
		return elist;
	}

}
