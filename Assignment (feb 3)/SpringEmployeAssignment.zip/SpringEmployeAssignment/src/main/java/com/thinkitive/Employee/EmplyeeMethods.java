package com.thinkitive.Employee;

import java.util.List;

public interface EmplyeeMethods {
	
	
	public void addEmployee(Employee e);
	public void deleteEmployee(int empid);
	public void updateEmployee(Employee e);
	public Employee getEmployee(int empid);
	public List<Employee> getallEmployee();
	

}
