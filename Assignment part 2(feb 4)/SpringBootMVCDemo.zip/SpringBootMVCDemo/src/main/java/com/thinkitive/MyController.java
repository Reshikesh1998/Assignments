package com.thinkitive;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
@Autowired
MathOperations o;
int ans;
	@RequestMapping("/hi")
	public ModelAndView caller(int first, int second, String operation) 
	{
		System.out.println("hello u r in control");
		if(operation.equals("1")) 
		{
			System.out.println("inside add");
			ans=o.add(first, second);
		}
		if(operation.equals("2"))
		{
			ans=o.sub(first, second);
		}
		if(operation.equals("3"))
		{
			ans=o.mul(first, second);
		}
		if(operation.equals("4")) 
		{
			ans=	o.div(first, second);
		}
		
		
		ModelAndView view = new ModelAndView();
		view.addObject("ans", ans);
		view.setViewName("index.jsp");
		return view;
		
		
	}
	
}
