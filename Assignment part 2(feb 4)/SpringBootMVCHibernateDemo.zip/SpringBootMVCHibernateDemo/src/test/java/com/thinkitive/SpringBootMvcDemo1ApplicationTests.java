package com.thinkitive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMvcDemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
