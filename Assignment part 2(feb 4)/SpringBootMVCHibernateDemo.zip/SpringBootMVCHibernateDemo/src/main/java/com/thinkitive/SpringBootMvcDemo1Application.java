package com.thinkitive;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMvcDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMvcDemo1Application.class, args);
		
		Configuration cfg = new  Configuration();
		SessionFactory factory = cfg.configure().buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		
		
		Employee e = new Employee(1, "abc", 222);
		session.save(e);
	}

}
