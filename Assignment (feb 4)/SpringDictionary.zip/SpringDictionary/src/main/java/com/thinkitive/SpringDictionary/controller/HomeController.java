package com.thinkitive.SpringDictionary.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mysql.fabric.xmlrpc.base.Member;
import com.thinkitive.dictionary.Dictionary;
import com.thinkitive.dictionary.Members;

@Controller
public class HomeController {

Configuration cfg ;
SessionFactory factory;
Session session;
Transaction tx;
public HomeController() {
	cfg = new Configuration();
	factory = cfg.configure().buildSessionFactory();
	
}

	@RequestMapping(value="/")
	public ModelAndView test(HttpServletResponse response) throws IOException{
		return new ModelAndView("home");
	}
	
	@RequestMapping("/login")
	public ModelAndView login(String uname, String upass) 
	{
		ModelAndView model = new ModelAndView();
		
		if(uname.equals("admin") && upass.equals("admin")) 
		{
			model.setViewName("adminpage.jsp");
			
		}
		
		else 
		{
			session = factory.openSession();
			tx= session.beginTransaction();
			Members m = new Members(uname, upass);
			//session.save(m);
			//tx.commit();
			String hql = "select id from Members where mname= :uname and mpass= :upass";
			Query query = session.createQuery(hql);
			query.setParameter("uname", uname);
			query.setParameter("upass", upass);
			List result = query.list();
		
			if(result.isEmpty()) 
			{
				model.setViewName("login.jsp");
				model.addObject("message", "Login unsuccessful");
				session.close();
			}
			else {
			model.addObject("message", "Login successful");
			model.setViewName("userpage.jsp");
			session.close();
			}
			
			
		}
		
		return model;
		
		
	}
	@RequestMapping("/user")
	public ModelAndView user(String word, String operation) 
	{
		ModelAndView model = new ModelAndView();
		
		
		
		
		
		if(operation.equals("1")) 
		{
			session = factory.openSession();
			tx = session.beginTransaction();
			
			Criteria c = session.createCriteria(Dictionary.class);
			c.add(Restrictions.eqOrIsNull("word", word));
			List l = c.list();
			model.addObject("meaning", l.toString());
			session.close();
		}
		if(operation.equals("2")) 
		{
			session = factory.openSession();
			tx = session.beginTransaction();
			Query query = session.createQuery("From Dictionary");
			List l = query.list();
			model.addObject("wlist",l.toString());
			
			session.close();
			
			
			
		}
		
		model.setViewName("userpage.jsp");
		
		return model;
		
		
		
	}
	
	@RequestMapping("/admin")
	public ModelAndView admin(String word, String meaning, String operation) 
	{
		ModelAndView model = new ModelAndView();
		
		if(operation.equals("1")) 
		{
			session = factory.openSession();
			tx = session.beginTransaction();
			Dictionary d = new Dictionary(word,meaning);
			session.save(d);
			String message= "Added successfully";
			model.addObject("meaning", message);
			tx.commit();
			session.close();
		}
		
		if(operation.equals("2"))
		{
			session = factory.openSession();
			tx = session.beginTransaction();
			Dictionary d = new Dictionary(word,meaning);
			session.update(d);
			String message= "updated successfully";
			model.addObject("meaning", message);
			tx.commit();
			session.close();
			
		}
		if(operation.equals("3")) 
		{
			session = factory.openSession();
			tx = session.beginTransaction();
			Dictionary d = new Dictionary(word,meaning);
			session.delete(d);
			String message= "Deleted successfully";
			model.addObject("meaning", message);
			tx.commit();
			session.close();
		}
		if(operation.equals("4")) 
		{
			session = factory.openSession();
			tx = session.beginTransaction();
			
			Criteria c = session.createCriteria(Dictionary.class);
			c.add(Restrictions.eqOrIsNull("word", word));
			List l = c.list();
			model.addObject("meaning", l.toString());
			tx.commit();
			session.close();
		}
		if(operation.equals("5")) 
		{
			session = factory.openSession();
			tx = session.beginTransaction();
			Query query = session.createQuery("From Dictionary");
			List l = query.list();
			System.out.println(l.toString());
			model.addObject("meaning",l.toString());
			tx.commit();
			session.close();
		}
		
		
		
		model.setViewName("adminpage.jsp");
		return model;
	}
	
}
