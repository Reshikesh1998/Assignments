package com.thinkitive.dictionary;

public class Members {
private String mname;
private String mpass;
private int id;
public Members() {
	super();
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public Members(String mname, String mpass) {
	super();
	this.mname = mname;
	this.mpass = mpass;
}
public String getMname() {
	return mname;
}
public void setMname(String mname) {
	this.mname = mname;
}
public String getMpass() {
	return mpass;
}
public void setMpass(String mpass) {
	this.mpass = mpass;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + id;
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Members other = (Members) obj;
	if (id != other.id)
		return false;
	return true;
}
@Override
public String toString() {
	return "Members [mname=" + mname + ", mpass=" + mpass + ", id=" + id + "]";
}



}
