package com.thinkitive.Employee;

import java.util.List;

public interface EmplyeeMethods {
	
	
	public void addEmployee(Employee e);
	public void deleteEmployee(int empid, String ename, int salary);
	public void updateEmployee(Employee e);
	public String getEmployee(int empid);
	public List<Employee> getallEmployee();
	

}
